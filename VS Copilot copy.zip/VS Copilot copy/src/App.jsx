import FitnessTracker from './FitnessTracker.jsx'

function App() {
  return <FitnessTracker />
}

export default App